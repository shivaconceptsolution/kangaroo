from django.http import HttpResponse

def index(request):
	return HttpResponse("Hello World")

def addition(request):
     a=100
     b=200
     c=a+b
     return HttpResponse("Result is "+str(c))

def si(request):
    p=450000
    r=2.2
    t=3
    si = (p*r*t)/100
    return HttpResponse("Result is "+str(si))  

def prime(request):
    n=6
    c=0
    for i in range(1,n+1):
    	if n%i==0:
    		c=c+1
    if c==2:
       return HttpResponse("Prime")
    else:
       return HttpResponse("Not prime")     		
